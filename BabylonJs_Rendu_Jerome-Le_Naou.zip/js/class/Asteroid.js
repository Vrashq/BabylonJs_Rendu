(function(fps) {

    var Asteroid = function() {

    }


})(fps);